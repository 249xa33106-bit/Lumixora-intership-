import { useMemo, useState } from 'react';
import { ArrowRight, ArrowUpRight, Bot, BriefcaseBusiness, Building2, CheckCircle2, Code2, FileCheck2, GraduationCap, Megaphone, Palette, Search, ShieldCheck, Sparkles, Users, X } from 'lucide-react';
import './styles.css';

type RoleId = 'marketing' | 'software_testing' | 'content_creation' | 'research';
type Application = {
  id: string; name: string; email: string; phone: string; college: string;
  degree: string; year: string; location: string; role: RoleId;
  skills: string; motivation: string; hours: string; linkedin: string;
  portfolio: string; createdAt: string;
};
type Role = { id: RoleId; title: string; openings: number; summary: string; skills: string[]; icon: typeof Megaphone };

const domains = [
  { title: 'AI & Generative AI Development', desc: 'Build useful AI features, intelligent workflows, and practical student career tools.', icon: Bot },
  { title: 'Full-Stack Software Development', desc: 'Create reliable product experiences across frontend, backend, APIs, and integrations.', icon: Code2 },
  { title: 'Business Development & Employer Partnerships', desc: 'Build employer relationships and understand real hiring needs and opportunities.', icon: Building2 },
  { title: 'Growth Marketing & User Acquisition', desc: 'Improve reach, activation, retention, and measurable student adoption.', icon: Megaphone },
  { title: 'Campus Community & Partnerships', desc: 'Grow student communities and develop meaningful college partnerships.', icon: GraduationCap },
  { title: 'UI/UX & Product Design', desc: 'Make Lumixora clearer, easier to use, and more valuable for students and recruiters.', icon: Palette },
  { title: 'Content Creation & Brand Growth', desc: 'Create helpful content, product explainers, and consistent brand communication.', icon: Sparkles },
  { title: 'Software Quality Assurance & Testing', desc: 'Improve product quality through usability checks, regression testing, and clear bug reports.', icon: ShieldCheck }
];

const roles: Role[] = [
  { id: 'marketing', title: 'Marketing Intern', openings: 3, summary: 'Help grow awareness, engagement, and adoption of Lumixora.', skills: ['Social media', 'Campaigns', 'Analytics'], icon: Megaphone },
  { id: 'software_testing', title: 'Software Testing Intern', openings: 3, summary: 'Help test product journeys, find issues, and improve quality.', skills: ['Attention to detail', 'Test documentation', 'Communication'], icon: FileCheck2 },
  { id: 'content_creation', title: 'Content Creation Intern', openings: 2, summary: 'Create clear, useful content for students and the Lumixora brand.', skills: ['Writing', 'Creativity', 'Short-form content'], icon: Sparkles },
  { id: 'research', title: 'Research Intern', openings: 2, summary: 'Research student needs, market gaps, and product opportunities.', skills: ['Research', 'Critical thinking', 'Synthesis'], icon: Search }
];

const emptyForm = {
  name: '', email: '', phone: '', college: '', degree: '', year: '', location: '',
  role: 'marketing' as RoleId, skills: '', motivation: '', hours: '10–15 hours/week',
  linkedin: '', portfolio: ''
};
const STORE_KEY = 'lumixora_batch01_applications_v1';

function readApplications(): Application[] {
  try {
    const value = localStorage.getItem(STORE_KEY);
    return value ? JSON.parse(value) as Application[] : [];
  } catch { return []; }
}

export default function App() {
  const [view, setView] = useState<'overview' | 'apply' | 'applications'>('overview');
  const [form, setForm] = useState(emptyForm);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState<string | null>(null);
  const [applications, setApplications] = useState<Application[]>(readApplications);
  const [search, setSearch] = useState('');
  const [adminMode, setAdminMode] = useState(false);

  const selectedRole = roles.find(r => r.id === form.role) ?? roles[0];
  const filteredApps = useMemo(() => applications.filter(a =>
    `${a.name} ${a.email} ${a.college} ${a.role}`.toLowerCase().includes(search.toLowerCase())
  ), [applications, search]);

  function update<K extends keyof typeof form>(key: K, value: typeof form[K]) {
    setForm(prev => ({ ...prev, [key]: value }));
    setErrors(prev => ({ ...prev, [key]: '' }));
  }

  function validate() {
    const next: Record<string, string> = {};
    const required: Array<keyof typeof form> = ['name', 'email', 'phone', 'college', 'degree', 'year', 'location', 'skills', 'motivation'];
    required.forEach(key => { if (!String(form[key]).trim()) next[key] = 'This field is required.'; });
    if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) next.email = 'Enter a valid email address.';
    if (form.motivation.trim().length > 0 && form.motivation.trim().length < 30) next.motivation = 'Please write at least 30 characters.';
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!validate()) return;
    const record: Application = { ...form, id: `LMX-B01-${Math.floor(1000 + Math.random() * 9000)}`, createdAt: new Date().toISOString() };
    const next = [record, ...readApplications()];
    localStorage.setItem(STORE_KEY, JSON.stringify(next));
    setApplications(next);
    setSubmitted(record.id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function exportCsv() {
    const headers = ['Reference', 'Name', 'Email', 'Phone', 'College', 'Degree', 'Year', 'Location', 'Role', 'Skills', 'Motivation', 'Hours', 'Created At'];
    const rows = applications.map(a => [a.id, a.name, a.email, a.phone, a.college, a.degree, a.year, a.location, roles.find(r => r.id === a.role)?.title ?? a.role, a.skills, a.motivation, a.hours, a.createdAt]);
    const csv = [headers, ...rows].map(row => row.map(value => `"${String(value ?? '').replace(/"/g, '""')}"`).join(',')).join('\r\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'lumixora-applications.csv'; a.click(); URL.revokeObjectURL(url);
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#" onClick={e => { e.preventDefault(); setView('overview'); setSubmitted(null); }}>
          <span className="brand-mark">L</span>
          <span className="brand-copy"><strong>LUMIXORA</strong><small>A PRODUCT OF VYOMRA</small></span>
        </a>
        <nav className="nav-links">
          <button className={view === 'overview' ? 'nav-active' : ''} onClick={() => { setView('overview'); setSubmitted(null); }}>Program</button>
          <a href="#domains" onClick={() => { setView('overview'); setSubmitted(null); }}>Domains</a>
          <a href="#roles" onClick={() => { setView('overview'); setSubmitted(null); }}>Open roles</a>
        </nav>
        <div className="nav-actions">
          <button className="text-button" onClick={() => { setView('applications'); setSubmitted(null); }}>Applications</button>
          <button className="btn btn-primary btn-small" onClick={() => { setView('apply'); setSubmitted(null); }}>Apply now <ArrowRight size={15}/></button>
        </div>
      </header>

      <main>
        {submitted ? (
          <section className="success-panel">
            <div className="success-icon"><CheckCircle2 size={32}/></div>
            <p className="eyebrow">APPLICATION RECEIVED</p>
            <h1>Thanks for taking the next step.</h1>
            <p>Your application has been saved in this browser. Keep your reference ID for your records.</p>
            <div className="reference-box"><span>Application reference</span><strong>{submitted}</strong><button onClick={() => navigator.clipboard?.writeText(submitted)}>Copy ID</button></div>
            <p className="small-note">This starter version does not send email or sync applications across devices.</p>
            <button className="btn btn-primary" onClick={() => { setForm(emptyForm); setSubmitted(null); setView('overview'); }}>Back to program <ArrowRight size={16}/></button>
          </section>
        ) : view === 'apply' ? (
          <section className="form-layout">
            <div className="form-intro">
              <p className="eyebrow">BATCH 01 · APPLICATION</p>
              <h1>Bring your skills.<br/><span>Build what’s next.</span></h1>
              <p>Tell us about yourself, choose your preferred role, and show us what you can contribute to Lumixora.</p>
              <div className="mini-facts"><span><CheckCircle2 size={16}/> Remote program</span><span><CheckCircle2 size={16}/> Six-week learning experience</span><span><CheckCircle2 size={16}/> Practical startup work</span></div>
              <button className="back-link" onClick={() => setView('overview')}>← Back to program overview</button>
            </div>
            <form className="application-form" onSubmit={submit} noValidate>
              <div className="form-heading"><div><p className="eyebrow">YOUR APPLICATION</p><h2>Candidate details</h2></div><span className="required-label">* Required</span></div>
              <div className="field-grid">
                <Field label="Full name" name="name" value={form.name} error={errors.name} onChange={v => update('name', v)} placeholder="Your full name" />
                <Field label="Email address" name="email" value={form.email} error={errors.email} onChange={v => update('email', v)} placeholder="you@example.com" type="email" />
                <Field label="Phone number" name="phone" value={form.phone} error={errors.phone} onChange={v => update('phone', v)} placeholder="+91 ..." />
                <Field label="College / university" name="college" value={form.college} error={errors.college} onChange={v => update('college', v)} placeholder="Institution name" />
                <Field label="Degree and branch" name="degree" value={form.degree} error={errors.degree} onChange={v => update('degree', v)} placeholder="B.Tech CSE, BBA, BCA..." />
                <div className="field"><label htmlFor="year">Current year of study *</label><select id="year" value={form.year} onChange={e => update('year', e.target.value)}><option value="">Select year</option><option>1st Year</option><option>2nd Year</option><option>3rd Year</option><option>4th Year / Final Year</option><option>Postgraduate</option><option>Recent Graduate</option></select><Error text={errors.year}/></div>
                <Field label="City and state" name="location" value={form.location} error={errors.location} onChange={v => update('location', v)} placeholder="Kurnool, Andhra Pradesh" />
                <div className="field"><label htmlFor="role">Preferred internship role *</label><select id="role" value={form.role} onChange={e => update('role', e.target.value as RoleId)}>{roles.map(r => <option key={r.id} value={r.id}>{r.title} · {r.openings} openings</option>)}</select></div>
                <div className="field full"><label htmlFor="skills">Relevant skills *</label><textarea id="skills" rows={3} value={form.skills} onChange={e => update('skills', e.target.value)} placeholder="Tools, strengths, skills, or experience you can contribute..."/><Error text={errors.skills}/></div>
                <div className="field full"><label htmlFor="motivation">Why do you want to join Lumixora? *</label><textarea id="motivation" rows={4} value={form.motivation} onChange={e => update('motivation', e.target.value)} placeholder="Tell us what interests you and how you would contribute..."/><Error text={errors.motivation}/></div>
                <div className="field"><label htmlFor="hours">Weekly availability</label><select id="hours" value={form.hours} onChange={e => update('hours', e.target.value)}><option>5–10 hours/week</option><option>10–15 hours/week</option><option>15–20 hours/week</option><option>20+ hours/week</option></select></div>
                <Field label="LinkedIn URL (optional)" name="linkedin" value={form.linkedin} onChange={v => update('linkedin', v)} placeholder="https://linkedin.com/in/..." optional />
                <Field label="Portfolio / work URL (optional)" name="portfolio" value={form.portfolio} onChange={v => update('portfolio', v)} placeholder="GitHub, portfolio, drive link..." optional />
              </div>
              <label className="consent"><input type="checkbox" required/> <span>I confirm that the information above is accurate and agree to its use for internship recruitment, subject to the published privacy notice.</span></label>
              <p className="small-note">Only submit information you are comfortable sharing. Connect a secure backend and publish a full privacy notice before using this starter for live recruitment.</p>
              <button className="btn btn-primary submit-btn" type="submit">Submit application <ArrowRight size={16}/></button>
            </form>
          </section>
        ) : view === 'applications' ? (
          <section className="dashboard">
            <div className="section-heading"><div><p className="eyebrow">LOCAL DEMO DASHBOARD</p><h1>Applications</h1><p>Applications saved in this browser only.</p></div><button className="btn btn-outline" onClick={exportCsv}>Export CSV <ArrowUpRight size={16}/></button></div>
            <div className="notice"><ShieldCheck size={18}/><span>This is a local prototype, not a secure admin system. Do not expose this page with real applicant data until authentication and a protected backend are implemented.</span></div>
            <div className="dashboard-toolbar"><div className="search-box"><Search size={17}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search name, email, college..."/></div><span>{filteredApps.length} application{filteredApps.length === 1 ? '' : 's'}</span></div>
            {filteredApps.length === 0 ? <div className="empty-state"><Users size={28}/><h3>No applications found</h3><p>Submitted applications from this browser will appear here.</p><button className="btn btn-primary" onClick={() => setView('apply')}>Open application form</button></div> :
              <div className="table-wrap"><table><thead><tr><th>Candidate</th><th>College</th><th>Preferred role</th><th>Submitted</th><th>Reference</th></tr></thead><tbody>{filteredApps.map(a => <tr key={a.id}><td><strong>{a.name}</strong><small>{a.email}</small></td><td>{a.college}<small>{a.degree}</small></td><td>{roles.find(r => r.id === a.role)?.title}</td><td>{new Date(a.createdAt).toLocaleDateString()}</td><td><code>{a.id}</code></td></tr>)}</tbody></table></div>}
          </section>
        ) : (
          <>
            <section className="hero">
              <div className="hero-content">
                <div className="hero-badge"><span className="pulse-dot"/> INTERNSHIP PROGRAM · BATCH 01</div>
                <h1>Don’t just learn.<br/><span>Help build the future.</span></h1>
                <p className="hero-description">Join the team building Lumixora — a student career and placement platform designed to connect skills, opportunities, and real-world progress.</p>
                <div className="hero-actions"><button className="btn btn-primary" onClick={() => setView('apply')}>Apply for Batch 01 <ArrowRight size={17}/></button><a className="btn btn-outline" href="#domains">Explore domains <ArrowUpRight size={17}/></a></div>
                <div className="hero-trust"><span><CheckCircle2 size={16}/> Remote-first</span><span><CheckCircle2 size={16}/> Practical deliverables</span><span><CheckCircle2 size={16}/> Startup exposure</span></div>
              </div>
              <div className="hero-visual" aria-label="Lumixora growth illustration">
                <div className="visual-orbit orbit-one"/><div className="visual-orbit orbit-two"/>
                <div className="visual-core"><span className="core-logo">L</span><strong>LUMIXORA</strong><small>CONNECTING THE FUTURE</small></div>
                <div className="float-card card-one"><span className="float-icon purple"><Code2 size={18}/></span><span><strong>Build</strong><small>Product & technology</small></span></div>
                <div className="float-card card-two"><span className="float-icon green"><Users size={18}/></span><span><strong>Grow</strong><small>Community & reach</small></span></div>
                <div className="float-card card-three"><span className="float-icon orange"><BriefcaseBusiness size={18}/></span><span><strong>Connect</strong><small>Students & employers</small></span></div>
                <div className="visual-spark spark-a">✳</div><div className="visual-spark spark-b">✦</div>
              </div>
              <div className="hero-footnote"><span>01 / BUILD WITH PURPOSE</span><span>REMOTE · SIX-WEEK PROGRAM</span></div>
            </section>

            <section className="stats-strip">
              <div><strong>08</strong><span>Strategic growth domains</span></div><div><strong>04</strong><span>Currently listed roles</span></div><div><strong>06 <small>weeks</small></strong><span>Program duration</span></div><div><strong>100%</strong><span>Remote participation</span></div>
            </section>

            <section className="section domains-section" id="domains">
              <div className="section-heading"><div><p className="eyebrow">WHERE WE’RE GROWING</p><h2>Eight domains. <span>One mission.</span></h2><p>Help Lumixora improve its product, reach more students, and build a stronger employer ecosystem.</p></div><span className="section-index">01 — 08</span></div>
              <div className="domain-grid">{domains.map((d, i) => { const Icon = d.icon; return <article className="domain-card" key={d.title}><div className="domain-top"><span className="domain-number">{String(i + 1).padStart(2, '0')}</span><span className="domain-icon"><Icon size={20}/></span></div><h3>{d.title}</h3><p>{d.desc}</p><span className="card-arrow"><ArrowUpRight size={17}/></span></article>; })}</div>
            </section>

            <section className="roles-section" id="roles">
              <div className="section section-heading"><div><p className="eyebrow">BATCH 01 · CURRENT OPENINGS</p><h2>Choose where you <span>make an impact.</span></h2><p>These are the four roles currently listed for this batch. The eight domains above describe Lumixora’s broader growth priorities, not additional confirmed vacancies.</p></div><span className="section-index">10 PLANNED SLOTS</span></div>
              <div className="role-grid">{roles.map(role => { const Icon = role.icon; return <article className="role-card" key={role.id}><div className="role-icon"><Icon size={21}/></div><div className="role-meta"><span>BATCH 01</span><span>{role.openings} openings</span></div><h3>{role.title}</h3><p>{role.summary}</p><div className="skill-tags">{role.skills.map(s => <span key={s}>{s}</span>)}</div><button onClick={() => { setForm(prev => ({ ...prev, role: role.id })); setView('apply'); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="role-apply">Apply for this role <ArrowRight size={16}/></button></article>; })}</div>
            </section>

            <section className="program-band"><div className="band-icon"><GraduationCap size={24}/></div><div><p className="eyebrow">LEARN BY CONTRIBUTING</p><h2>Make your work count.</h2><p>A six-week remote learning experience focused on practical deliverables, collaboration, and startup exposure.</p></div><button className="btn btn-light" onClick={() => setView('apply')}>Start application <ArrowRight size={16}/></button></section>

            <section className="disclosure"><div className="disclosure-icon"><ShieldCheck size={20}/></div><div><strong>Program transparency</strong><p>This is a learning-focused internship program. Selection, certificate, recommendation, and any compensation or grants are subject to written program terms and actual eligibility. No permanent job or placement is guaranteed. Confirm compensation and legal requirements before publishing recruitment claims.</p></div></section>
          </>
        )}
      </main>

      <footer className="footer"><a className="brand footer-brand" href="#" onClick={e => { e.preventDefault(); setView('overview'); }}><span className="brand-mark">L</span><span className="brand-copy"><strong>LUMIXORA</strong><small>A PRODUCT OF VYOMRA</small></span></a><span>Connecting the Future.</span><span>© {new Date().getFullYear()} Lumixora · Internship Program</span></footer>
      <button className="demo-link" onClick={() => setAdminMode(v => !v)}>{adminMode ? <X size={14}/> : <ShieldCheck size={14}/>} {adminMode ? 'Hide demo tools' : 'Demo tools'}</button>
      {adminMode && <div className="demo-popover"><strong>Prototype controls</strong><p>This build uses browser-local storage. Applications are not shared with the founder or other devices.</p><button onClick={() => { localStorage.removeItem(STORE_KEY); setApplications([]); }}>Clear local demo applications</button><button onClick={() => { setView('applications'); setAdminMode(false); }}>View local applications</button></div>}
    </div>
  );
}

function Error({ text }: { text?: string }) { return text ? <small className="field-error">{text}</small> : null; }
function Field({ label, name, value, onChange, placeholder, error, type = 'text', optional = false }: { label: string; name: string; value: string; onChange: (v: string) => void; placeholder: string; error?: string; type?: string; optional?: boolean }) {
  return <div className="field"><label htmlFor={name}>{label}{optional ? ' (optional)' : ' *'}</label><input id={name} name={name} type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}/><Error text={error}/></div>;
}
