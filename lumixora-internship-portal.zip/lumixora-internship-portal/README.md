# Lumixora Internship Portal

A responsive, light-mode React + TypeScript + Vite portal for the Lumixora Internship Program, Batch 01.

## Included
- Eight strategic internship growth domains
- Four currently listed Batch 01 application roles
- Responsive application form with required-field validation
- Applications saved in browser localStorage
- Admin-style applications view with search and CSV export
- Vercel configuration

## Run locally
1. Install Node.js 20 or newer.
2. Open this folder in a terminal.
3. Run `npm install`
4. Run `npm run dev`

## Production build
Run `npm run build`. Vite outputs the production site into `dist/`.

## Deploy to Vercel
1. Upload this folder to a new GitHub repository, or import it into Vercel.
2. Use the Vite preset.
3. Build command: `npm run build`
4. Output directory: `dist`

## Important data note
This starter stores applications in the applicant's browser only. It does not provide shared cross-device storage, authentication, or email delivery. Before collecting real applicant information, connect a secure backend such as Firebase/Firestore and configure appropriate access rules and privacy notices. Do not use browser-only storage as a production recruitment database.
